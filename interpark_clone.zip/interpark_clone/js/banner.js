window.addEventListener("DOMContentLoaded", function() {
    
    // 슬라이드 갯수
    const total = 6;

    // 슬라이드 배치 장소
    const bannerPos = document.querySelector(".sw_banner")

    // html 태그 만들기
    const tag = `
    <div class="swiper-slide">
        <a href="#" class="banner_slide_item">
            <img src="images/s1.jpg" alt="이미지" />
        </a>
    </div>
    `
    // 6개 만들기
    let htmlTag = tag + tag + tag + tag + tag + tag;
    console.log(htmlTag);

    // html 장소에 배치하기
    bannerPos.innerHTML = htmlTag;

    // 슬라이드 만들기
    

    const swiper = new Swiper(".sw_banner", {
        slidesPerView: 2,
        spaceBetween: 25,
        loop: true,
        speed: 1000,
        autoplay: {
            delay: 2000,
            disableOnInteraction: false,
        },

        navigation: {
            nextEl: ".banner_slide_next",
            prevEl: ".banner_slide_prev",
        },
    });
});